<!-- Footer opened -->
<div class="main-footer ht-40">
	<div class="container-fluid pd-t-0-f ht-100p">
		<p class="mb-0"> &copy; Copyright <span id="copyright"><script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span> <a href="https://wa.me/+201016856433"  target="_blank">Eng.Ahmed Nabil <i class="mdi mdi-whatsapp whatsapp-icon" style="color:green"></i></a> All Rights Reserved.</p>
	</div>
</div>
<!-- Footer closed -->
